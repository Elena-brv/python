import sys
import os

print(os.name) #имя ОС
print(sys.platform) #платформа
print(os. cpu_count()) #количество ядер