number = int (input('Enter the number: '))

if number % 2 == 0:
    print ('It’s even number')
else:
    print ('It’s odd number')