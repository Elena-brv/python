my_list = [1, 85, 65, 2, 34, 23, 5]
summa = 0
for element in my_list:
    summa = summa + element
print (summa)
