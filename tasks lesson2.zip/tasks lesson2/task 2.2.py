base_of_triangle = float (input('Base of triangle in sm = ')) 
height_of_triangle = float (input('Height of triangle in sm = ')) 

area_of_triangle = 0.5 * base_of_triangle * height_of_triangle
print(f'Area of tre triangle = {area_of_triangle} sm')